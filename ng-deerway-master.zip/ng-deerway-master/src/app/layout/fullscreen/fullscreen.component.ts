import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fullscreen',
  templateUrl: './fullscreen.component.html',
  styleUrls: ['./fullscreen.component.less']
})
export class FullscreenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
