import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auto-calu',
  templateUrl: './auto-calu.component.html',
  styleUrls: ['./auto-calu.component.css']
})
export class AutoCaluComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
