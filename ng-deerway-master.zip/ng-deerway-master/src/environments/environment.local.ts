export const environment = {
    production: false,
    urlPrefix: 'https://www.yiyudata.com/api/',
};
