export const environment = {
  production: true,
  urlPrefix: 'https://www.yiyudata.com/api/',
};
